//
//  ContactView.swift
//  AboutMe
//
//  Created by Rehaan Anjaria on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Link(destination: URL(string: "https://www.instagram.com/aryashirke05")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding(20)
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                Link(destination: URL(string: "https://www.linkedin.com/in/aryashirke/")!) {
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .padding(20)
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
            }
            
        }
    }
}

#Preview {
    ContactView()
}
