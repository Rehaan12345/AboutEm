//
//  SwiftUIView.swift
//  AboutMe
//
//  Created by Rehaan Anjaria on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills") {
                    Text("Xcode")
                    Text("Sketching")
                    Text("Chess")
                    Text("Cooking")
                }
                Section("Courses") {
                    Text("CSCI 103")
                    Text("CSCI 170")
                    Text("TAC 325")
                    Text("Writ 150")
                }
            }
        }
        .navigationTitle("More Skills")
    }
}

#Preview {
    MoreView()
}
