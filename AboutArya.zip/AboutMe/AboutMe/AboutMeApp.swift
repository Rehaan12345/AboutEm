//
//  AboutMeApp.swift
//  AboutMe
//
//  Created by Rehaan Anjaria on 2/11/26.
//

import SwiftUI

@main
struct AboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
