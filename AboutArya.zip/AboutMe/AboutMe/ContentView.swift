//
//  ContentView.swift
//  AboutMe
//
//  Created by Rehaan Anjaria on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["dancing", "playing tennis", "cooking"]
    var body: some View {
        TabView {
            Tab("About", systemImage: "person") {
                AboutView()
            }
            Tab("Contact", systemImage: "phone") {
                ContactView()
            }
            Tab("More", systemImage: "ellipsis") {
                MoreView()
            }
            
        }
    }
}

#Preview {
    ContentView()
}
