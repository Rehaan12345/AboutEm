//
//  ContentView.swift
//  AboutMe
//
//  Created by Rehaan Anjaria on 2/11/26.
//

import SwiftUI

struct AboutView: View {
    let hobbies = ["dancing", "playing tennis", "cooking"]
    var body: some View {
        ZStack {
            Color.purple.opacity(0.2)
                .ignoresSafeArea()
            VStack {
                Image("Primary").resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(color: .purple, radius: 35)
                    .padding(20)
                Text("Hello, I'm Arya Shirke! Apple on!")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.serif)
                
                Text("I love \(hobbies.formatted())")
                
                HStack {
                    Image(systemName: "iphone.crop.circle")
                    Image(systemName: "macbook")
                    Image(systemName: "airpods.pro")
                    Image(systemName: "ipad")
                    Image(systemName: "applewatch.watchface")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                
                Text("Fun Fact")
                    .font(.title)
                    .bold()
                Text("I love to draw and paint!")
                
                Spacer()
                    .frame(height: 50)
                
                Text("Favorite Apple product:")
                HStack {
                    Text("iPhone")
                        .bold()
                        .italic()
                    Image(systemName: "iphone.gen2.sizes")
                }
            }
            .padding().multilineTextAlignment(.center)
        }
    }
}

#Preview {
    ContentView()
}
